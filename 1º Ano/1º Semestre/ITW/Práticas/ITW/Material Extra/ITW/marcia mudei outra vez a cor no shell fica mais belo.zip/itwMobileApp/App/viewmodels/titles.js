define(function() {
	function processAuthors(arrAuthors) 
	{
		for (var i = 0; i < arrAuthors.length; i++) 
			$("#authorsList").append('<option value="' + arrAuthors[i].ID + '">' + arrAuthors[i].name+ '</option>');
	}
	
	function getAuthors(url)
	{
		$.ajax({
			type: "GET",
			url: url,
			dataType: "jsonp",
			success: processAuthors,
			error: function (xhr, status, err) {
				alert('Erro a ler o ficheiro :'+url);
			}
		});
	}
	
    return {
		displayName : 'titles',
		selectedAuthor: ko.observable(''), 
		activate: function(){
			
		},
		compositionComplete : function(){
			getAuthors('http://192.168.160.36/JSON/getAuthors.aspx?numAuthors=23');
		},
		changeAuthorData: function(){
			var urlTitles="http://192.168.160.36/JSON/getAuthorTitles.aspx?author_ID="+this.selectedAuthor();
			$.ajax({
				type: "GET",
				url: urlTitles,
				dataType: "jsonp",
				success: this.processTitles,
				error: function (xhr, status, err) {
					alert('Erro a ler o ficheiro :' + url);
				}
			});
		},
		processTitles : function(arrTitles)
		{
			var out = "<table class=\"table table-striped table-bordered\"><tr><th>Title</th><th>Authors</th><th>Type</th><th>Price</th><th>Ytd_Sales</th><th>Notes</th><th>Pubdate</th></tr>";
			for (var i = 0; i < arrTitles.length; i++)
			{
				out += '<tr><td>' + arrTitles[i].title + '</td><td>' +
				arrTitles[i].authors + '</td><td>' + arrTitles[i].type +
				'</td><td>' + arrTitles[i].price + '</td><td>' + 
				arrTitles[i].ytd_sales + '</td><td>' + arrTitles[i].notes + 
				'</td><td>' + arrTitles[i].pubdate + '</td></tr>';
			}
			out += "</table>";
			$("#titles").html(out);
		},
		
	};
	
});
