define(function() {
	function processAuthors(arrAuthors) 
	{
		var out = "<table class=\"table table-striped table-bordered table-condensed\"><tr><th>Picture</th><th>ID</th><th>Name</th><th>Phone</th><th>Address</th><th>City</th><th>State</th><th>Zip</th></tr>";
		for (var i = 0; i < arrAuthors.length; i++)
		{
			out += '<tr><td>' + "<img src=\"http://192.168.160.36/images/"+ arrAuthors[i].ID +".png\" style=\"border-radius:64px;\">" + '</td><td>' + arrAuthors[i].ID + '</td><td>' +
			arrAuthors[i].name + '</td><td>' + arrAuthors[i].phone + 
			'</td><td>' + arrAuthors[i].address + '</td><td>' + 
			arrAuthors[i].city + '</td><td>' + arrAuthors[i].state + 
			'</td><td>' + arrAuthors[i].zip + '</td><td>' + "</td></tr>";
		}
		out += "</table>";
		$("#authors").html(out);
	}
	
	function getAuthors(url)
	{
		$.ajax({
			type: "GET",
			url: url,
			dataType: "jsonp",
			success: processAuthors,
			error: function (xhr, status, err) {
				alert('Erro a ler o ficheiro :'+url);
			}
		});
	}
	return {
		displayName : 'authors',
		activate: function(){
			
		},
		compositionComplete : function(){
			getAuthors('http://192.168.160.36/JSON/getAuthors.aspx?numAuthors=23');
		},
		
	};
});