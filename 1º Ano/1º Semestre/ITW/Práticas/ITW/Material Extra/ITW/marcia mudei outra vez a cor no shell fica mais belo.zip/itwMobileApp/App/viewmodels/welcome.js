﻿define(function() {
    return {
        //displayName : '',
        //description : '',
        //features : [
        //]
    };
});