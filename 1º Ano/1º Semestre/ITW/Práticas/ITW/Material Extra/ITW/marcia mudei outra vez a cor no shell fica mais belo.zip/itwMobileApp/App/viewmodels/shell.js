﻿define(['plugins/router', 'durandal/app'], function (router, app) {
    return {
        router: router,
        activate: function () {
            router.map([
                { route: '', title:'Welcome', moduleId: 'viewmodels/welcome', nav: true, menu : '<i class="fa fa-home"></i>' },
				{ route: 'authors', moduleId: 'viewmodels/authors', nav: true, menu : '<i class="fa fa-users"></i>' },
				{ route: 'titles', moduleId: 'viewmodels/titles', nav: true, menu : '<i class="fa fa-file-text"></i>' },
				{ route: 'sales', moduleId: 'viewmodels/sales', nav: true, menu : '<i class="fa fa-euro"></i>' }
            ]).buildNavigationModel();
            
            return router.activate();
        }
    };
});