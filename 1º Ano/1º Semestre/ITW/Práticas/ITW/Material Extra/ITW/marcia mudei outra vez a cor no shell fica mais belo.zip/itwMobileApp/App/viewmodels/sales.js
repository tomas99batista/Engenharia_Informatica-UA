define(function() {
	function processAuthors(arrAuthors) 
	{
		for (var i = 0; i < arrAuthors.length; i++) 
			$("#authorsList").append('<option value="' + arrAuthors[i].ID + '">' + arrAuthors[i].name+ '</option>');
	}
			
	function getAuthors(url)
	{
		$.ajax({
			type: "GET",
			url: url,
			dataType: "jsonp",
			success: processAuthors,
			error: function (xhr, status, err) {
				alert('Erro a ler o ficheiro :'+url);
			}
		});
	}
	
    return {
		displayName : 'sales',
		selectedAuthor: ko.observable(''), 
		activate: function(){
			
		},
		compositionComplete : function(){
			getAuthors('http://192.168.160.36/JSON/getAuthors.aspx?numAuthors=23');
		},
		changeAuthorData: function(){
			var urlSales="http://192.168.160.36/JSON/getAuthorSales.aspx?author_ID="+this.selectedAuthor();
			$.ajax({
				type: "GET",
				url: urlSales,
				dataType: "jsonp",
				success: this.processSales,
				error: function (xhr, status, err) {
					alert('Erro a ler o ficheiro :' + url);
				}
			});
		},
		processSales : function(arrSales)
		{
			var out = "<table class=\"table table-striped table-bordered table-condensed\">";
			out += "<thead><tr><th>Title</th><th>Sales</th></tr></thead>";
			for (var i = 0; i < arrSales.length; i++)
			{
				out += '<tr><td>' + arrSales[i].title + '</td><td>'
				+ "<table class=\"table table-striped table-bordered table-condensed\"><tr><th>orderNum</th><th>orderDate</th><th>quantity</th><th>payTerms</th><th>store</th></tr>";
				for (var j = 0; j < arrSales[i].sales.length; j++)
				{
					out += "<tr><td>" + arrSales[i].sales[j].orderNum + "</td>"
					 + "<td>" + arrSales[i].sales[j].orderDate + "</td>"
					 + "<td>" + arrSales[i].sales[j].quantity + "</td>"
					 + "<td>" + arrSales[i].sales[j].payTerms + "</td>"
					 + "<td>" + arrSales[i].sales[j].store.name + "<br>" + arrSales[i].sales[j].store.address + "<br>" + arrSales[i].sales[j].store.city + ", " + arrSales[i].sales[j].store.state + ", " + arrSales[i].sales[j].store.zip + "</td>"+ "</tr>";
				}
				out += "</table></td></tr>";
			}
			out += "</table>";
			$("#sales").html(out);
		}
    };
});