﻿//--- função para cálculo da média
function calcula() {
    var ALGA_C = document.getElementById("ALGA_C").value;
    var FIS_C = document.getElementById("FIS_C").value;
    var CALC1_C = document.getElementById("CALC1_C").value;
    var ITW_C = document.getElementById("ITW_C").value;
    var FP_C = document.getElementById("FP_C").value;
    var M1S_C = document.getElementById("M1S_C");
    M1S_C.value = (ALGA_C * 1.0 + FIS_C * 1.0 + ITW_C * 1.0 + CALC1_C * 1.0 + FP_C * 1.0);


    return true;
}

function checkCredit(value) {
    return (value < 4 || value > 10);
}

function checkNota(value) {

}
