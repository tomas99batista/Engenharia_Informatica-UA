package A02;
import java.util.Scanner;
public class E4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner kb = new Scanner(System.in);
		
		int n;
		do{
			System.out.print("n?");
			n = kb.nextInt();
		}while(n != 0);
		
		System.out.print("primeiro?");
		n = kb.nextInt();
		while(n != 0){
			System.out.print("n?");
			n = kb.nextInt();
		}
		
		while(true){
			System.out.print("n3?");
			n = kb.nextInt();
			if(n == 0){
				break;
			}
		}
	}

}
