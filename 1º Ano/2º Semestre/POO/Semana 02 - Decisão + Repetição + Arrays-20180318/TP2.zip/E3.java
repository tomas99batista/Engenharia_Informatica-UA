package A02;
import java.util.Scanner;
public class E3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner kb = new Scanner(System.in);
		
		String a[] = new String[5];
		
		for(int i = 0 ; i < a.length ; i+=1){
			System.out.print("texto?");
			a[i] = kb.nextLine();
		}
		
		for(String s : a){
			System.out.println(s);
		}
	}

}
