package A02;

import java.util.Scanner;

public class E6 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		// ler dez numeros e contar positivos, negatovos e zeros
		int n = 0, p = 0, z = 0; // tres contadores
		int x;
		
		for(int i = 1 ; i <= 10 ; i += 1){ // repetir dez vezes
			System.out.print("n?");
			x = kb.nextInt();
			if(x > 0){
				p += 1;
			}
			else if(x < 0){
				n += 1;
			}
			else{
				z += 1;
			}
		}
		
		System.out.printf("postivos %d; negativos %d, zeros %d\n ", p, n, z);
	}

}
