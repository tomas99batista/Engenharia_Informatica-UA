package A02;

public class E2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i = 0 ; i < 10 ; i += 1){
			System.out.println(i);
		}
		
		// os pares entre 2 e 10
		for(int j = 2 ; j <= 10 ; j += 2){
			System.out.println("pares: " + j);
		}
	
		int k = 2;
		while(k <= 10){
			System.out.println("pares com while: " + k);
			k += 2;
		}
	}

}
