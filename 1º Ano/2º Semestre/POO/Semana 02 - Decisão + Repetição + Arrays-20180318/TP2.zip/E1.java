package A02;
import java.util.Scanner;

public class E1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner kb = new Scanner(System.in);
		int a[] = new int[5];

		System.out.println(a[0]);
		a[0] = 10;
		System.out.println(a[0]);

		for(int i : a){
			System.out.println("dentro do for:" + i);
		}

		double b[] = {10, 5.5, 25.2, 50.4}; // new automatico, neste caso dim = 4
		for(double j : b){
			System.out.println("dentro do for com reais:" + j);
		}

		// preencher o array pedindo valores ao teclado
		for(int i = 0 ; i < a.length ; i+=1){
			System.out.print("n?");
			a[i] = kb.nextInt();
		}
		
		for(int i : a){
			System.out.println("depois de preenchido com o teclado:" + i);
		}
	}

}
