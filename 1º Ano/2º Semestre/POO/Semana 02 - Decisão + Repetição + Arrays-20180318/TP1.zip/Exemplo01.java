package A02;
import java.util.Scanner;

public class Exemplo01 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		int a[] = new int[10];
		
		System.out.println(a[0]);
		a[0] = kb.nextInt();
		System.out.println(a[0]);
		
	}

}

