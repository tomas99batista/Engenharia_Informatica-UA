package A02;
import java.util.Scanner;
public class Exemplo6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner kb = new Scanner(System.in);
		int op;
		
		do{
			System.out.println("opcao?");
			op = kb.nextInt();
			
			if(op == 0)
				System.out.println("Sair");
			else if(op == 1)
				System.out.println("QQ1");
			else if(op == 2)
				System.out.println("QQ2");
			else
				System.out.println("Nao implementado");
			
		}while(op != 0);
		
		do{
			System.out.println("opcao?");
			op = kb.nextInt();
			
			switch(op){
			case 0: 
				System.out.println("Sair");
				break;
			case 1: 
				System.out.println("QQ1");
				break;
			case 2:
				System.out.println("QQ2");
				break;
			default:
				System.out.println("Nao implementado");
			}
		}while(op != 0);
		
		
	}

}
