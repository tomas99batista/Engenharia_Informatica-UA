package A02;

import java.util.Scanner;

public class Exemplo02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner kb = new Scanner(System.in);
		
		int a[] = {10, 20, 30, 40, 50};
		
		for(int i : a)
			System.out.println("a)" + i);
		
		for(int i = 0 ; i < a.length ; i++)
			System.out.println("b)" + a[i]);
		
		int i = 0;
		while(i < a.length){
			System.out.println("c)" + a[i]);
			i++;
		}
	}

}
