package A02;
import java.util.Scanner;
public class Exemplo4 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);

		// ler valores ate aparecer zero e imprimir valores por ordem inversa da sua introducao
		// no maximo considere 10 valores
		
		int a[] = new int[5];
		int cont = 0;
		int n;
		do{
			System.out.println("n?");
			n = kb.nextInt();
			if(n != 0){
				a[cont] = n;
				cont++;
			}
		}while(n != 0 && cont < a.length);
		
		for(int i = cont - 1 ; i >= 0 ; i--){
			System.out.println(a[i]);
		}
		
	}

}
