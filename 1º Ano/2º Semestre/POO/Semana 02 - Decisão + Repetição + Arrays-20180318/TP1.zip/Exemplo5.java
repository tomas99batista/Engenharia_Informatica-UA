package A02;
import java.util.Scanner;
public class Exemplo5 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		
		System.out.println("n?");
		int n = kb.nextInt();
		if(n > 0){
			System.out.println("Positivo");
		}
		else if(n < 0){
			System.out.println("Negativo");
		}
		else{
			System.out.println("Zero");
		}
			

	}

}
