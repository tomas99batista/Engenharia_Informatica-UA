package A02;
import java.util.Scanner;
public class Exemplo3 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		
		// impressao dos numeros pares ate 10, inclusive
		for(int i = 2 ; i <= 10 ; i += 2) // i = i + 2
			System.out.println(i);
		
		// ler numeros reais ate ser introduzido zero
		double n = 10; 
		while(n != 0.0){
			System.out.println("n1?");
			n = kb.nextDouble();
			System.out.println(n);
		}
		
		do{
			System.out.println("n2?");
			n = kb.nextDouble();
			System.out.println(n);
		}while(n != 0.0);
		
	}

}
