package a07;

public interface IDemo3 {
	
	default void metodo31() {}
	default void metodo32() {}
	
}
