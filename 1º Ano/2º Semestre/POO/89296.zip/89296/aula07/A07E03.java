package a07;

public class A07E03 {

	public static void main(String[] args) {
		
		
		Classe123 id123 = new Classe123("Cristiano", "Ronaldo");
		id123.metodo11(id123);
		id123.metodo123(id123);
		IDemo1 id1 = new Classe123("Tiago", "Mendes");

	}

}
