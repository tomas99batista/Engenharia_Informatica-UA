package a07;

public interface IDemo123 extends IDemo1, IDemo2, IDemo3 {
	
	default void metodo11() {}
	default void metodo12() {}
	
	default void metodo21() {}
	default void metodo22() {}
	
	default void metodo31() {}
	default void metodo32() {}
	
	default void metodo123() {}
}
