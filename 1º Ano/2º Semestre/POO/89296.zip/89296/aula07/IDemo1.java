package a07;

public interface IDemo1 {
	
	default void metodo11() {}
	
	default void metodo12() {}
}
