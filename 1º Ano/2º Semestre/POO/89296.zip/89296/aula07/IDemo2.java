package a07;

public interface IDemo2 {

	default void metodo21() {}
	default void metodo22() {}
	
}
