package a11;

public interface MotorEletrico { 
	double getAutonomia(); 
}
