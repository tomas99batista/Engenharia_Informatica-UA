package a11;
public interface MotorHibrido extends MotorCombustao, MotorEletrico {}
