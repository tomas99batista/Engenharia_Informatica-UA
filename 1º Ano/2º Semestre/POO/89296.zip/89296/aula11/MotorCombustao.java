package a11;

public interface MotorCombustao {
	double getEmissaoCO2();
}
