package a11;

public enum TipoLocalidade {
	Cidade, Vila, Aldeia
}
