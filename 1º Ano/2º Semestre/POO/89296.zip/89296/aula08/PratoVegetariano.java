package a08;

public class PratoVegetariano extends Prato {

	
	public PratoVegetariano(String nome, DiaSemana diaSem) {
		super(nome, diaSem);
	}
	
	public PratoVegetariano(String nome) {
		super(nome);
	}

}
