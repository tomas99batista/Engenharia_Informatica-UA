package a08;

public enum Variedade { VACA, PORCO, PERU, FRANGO, OUTRA }
