package a08;

public interface AlimentoVegetariano {}
