package a08;

public enum Tipo { CONGELADO, FRESCO }
