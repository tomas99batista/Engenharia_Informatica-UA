package A01;

public class Ex1 {

	public static void main(String[] args) {
		System.out.println("texto");
		System.out.println(10);
		System.out.print(5.5);
		System.out.println('a');
		System.out.printf("%5s %3d %4.1f %3c\n", "ola", 5, 25.4444, 'a');
		System.out.println("___.__");
		System.out.printf("%6.2f", 25.444444444);
	}

}
