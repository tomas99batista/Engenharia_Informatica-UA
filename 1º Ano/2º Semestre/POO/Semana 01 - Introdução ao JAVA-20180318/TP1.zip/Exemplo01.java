package A01;

public class Exemplo1 {

	public static void main(String[] args) {
		System.out.println("texto");
		System.out.print(10);
		System.out.println(10.5);
		System.out.println('a');
		System.out.printf("%3d %3.1f %3c %5s\n", 5, 25.321, 'a', "ola");
	}

}
