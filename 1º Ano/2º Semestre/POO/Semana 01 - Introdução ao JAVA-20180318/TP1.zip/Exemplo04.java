package A01;

public class Exemplo04 {

	public static void main(String[] args) {
		
		double a, b, c;
		
		a = 25.0;
		b = Math.sqrt(a);
		
		System.out.println(b);

	}

}
